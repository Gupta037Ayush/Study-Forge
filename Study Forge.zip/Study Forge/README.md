This Ed-Tech platform, developed using the MERN (MongoDB, Express.js, React.js, Node.js) stack, is a scalable solution designed to facilitate online learning. It provides role-based access controls, allowing users to have specific permissions based on their roles as "Admin," "Instructor," or "Student."

1- Role-Based Access Control:
Admin: Has overarching access to manage the platform, including approving instructors, monitoring student enrollment, and overseeing content.
Instructor: Can create, edit, and manage courses. Each course may have multiple videos and modules, which instructors can upload and organize.
Student: Has access to browse courses, purchase them, and access learning materials upon enrollment.

2- Course Creation and Management:
Instructors can create comprehensive courses, adding video content, quizzes, and assignments. Courses are structured to support multimedia content and interactive learning experiences.

3- Student Enrollment and Learning:
Students can browse available courses, purchase them, and access them through a personal dashboard. Once enrolled, students can view course content, track progress, and engage with the material.

4- Payment Integration with Razorpay API:
The platform integrates the Razorpay API to enable secure and seamless payments. Students can complete payments for course enrollments through Razorpay, which provides multiple payment options, transaction security, and a smooth user experience.

5- REST API for Backend Communication:
RESTful APIs are utilized for handling all backend operations, including user authentication, course management, video uploads, and payment transactions. This ensures that data is seamlessly and securely exchanged between the front end and back end, facilitating a smooth and efficient user experience.


